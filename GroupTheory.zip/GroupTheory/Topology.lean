/-
# Topology Proofs in Lean 4

Self-contained topology proofs without external dependencies.
-/

namespace TopologyTheory

/-- A Topological Space structure on a type X. -/
structure TopologicalSpace (X : Type u) where
  IsOpen : Set X → Prop
  isOpen_empty : IsOpen ∅
  isOpen_univ : IsOpen Set.univ
  isOpen_iUnion : ∀ {ι : Type*} (s : ι → Set X), (∀ i, IsOpen (s i)) → IsOpen (⋃ i, s i)
  isOpen_inter : ∀ {s t : Set X}, IsOpen s → IsOpen t → IsOpen (s ∩ t)

section TopologyProofs

variable {X : Type*}
variable (top : TopologicalSpace X)

/-- The empty set is open. -/
theorem empty_is_open : top.IsOpen ∅ := top.isOpen_empty

/-- The whole space is open. -/
theorem univ_is_open : top.IsOpen Set.univ := top.isOpen_univ

/-- The union of open sets is open. -/
theorem union_of_open_is_open (ι : Type*) (s : ι → Set X) 
    (h : ∀ i, top.IsOpen (s i)) : top.IsOpen (⋃ i, s i) := top.isOpen_iUnion s h

/-- The intersection of two open sets is open. -/
theorem inter_of_open_is_open (s t : Set X) 
    (hs : top.IsOpen s) (ht : top.IsOpen t) : top.IsOpen (s ∩ t) := top.isOpen_inter hs ht

/-- A set is closed if its complement is open. -/
def IsClosed (s : Set X) : Prop := top.IsOpen (sᶜ)

/-- The empty set is closed. -/
theorem empty_is_closed : IsClosed top ∅ := by
  unfold IsClosed
  rw [Set.compl_empty]
  apply univ_is_open top

/-- The whole space is closed. -/
theorem univ_is_closed : IsClosed top Set.univ := by
  unfold IsClosed
  rw [Set.compl_univ]
  apply empty_is_open top

/-- The intersection of two closed sets is closed. -/
theorem inter_of_closed_is_closed (s t : Set X) 
    (hs : IsClosed top s) (ht : IsClosed top t) : IsClosed top (s ∩ t) := by
  unfold IsClosed at *
  rw [Set.compl_inter]
  -- Need to show sᶜ ∪ tᶜ is open
  have h₁ : top.IsOpen sᶜ := hs
  have h₂ : top.IsOpen tᶜ := ht
  -- Union of open sets is open (using iUnion with Bool index)
  have : top.IsOpen (sᶜ ∪ tᶜ) := by
    apply top.isOpen_iUnion
    intro i
    cases i
    · exact h₁
    · exact h₂
  exact this

/-- The union of two closed sets is closed. -/
theorem union_of_closed_is_closed (s t : Set X) 
    (hs : IsClosed top s) (ht : IsClosed top t) : IsClosed top (s ∪ t) := by
  unfold IsClosed at *
  rw [Set.compl_union]
  apply inter_of_open_is_open top hs ht

/-- A function is continuous if the preimage of every open set is open. -/
def Continuous (f : X → X) : Prop := ∀ s : Set X, top.IsOpen s → top.IsOpen (f ⁻¹' s)

/-- The identity function is continuous. -/
theorem continuous_id : Continuous top id := by
  intro s hs
  rw [Set.preimage_id]
  exact hs

/-- The composition of continuous functions is continuous. -/
theorem continuous_comp (f g : X → X) 
    (hf : Continuous top f) (hg : Continuous top g) : Continuous top (g ∘ f) := by
  intro s hs
  rw [Set.preimage_comp]
  apply hf (g ⁻¹' s) (hg s hs)

/-- A constant function is continuous. -/
theorem continuous_const (c : X) : Continuous top (fun _ => c) := by
  intro s hs
  by_cases h : c ∈ s
  · rw [Set.preimage_const_of_mem h]
    apply univ_is_open top
  · rw [Set.preimage_const_of_not_mem h]
    apply empty_is_open top

/-- A homeomorphism is a bijective continuous function with continuous inverse. -/
structure Homeomorphism where
  toFun : X → X
  invFun : X → X
  continuous_toFun : Continuous top toFun
  continuous_invFun : Continuous top invFun
  left_inv : ∀ x, invFun (toFun x) = x
  right_inv : ∀ y, toFun (invFun y) = y

/-- Homeomorphism is reflexive. -/
theorem homeomorphism_reflexive : Homeomorphism top := by
  refine' {
    toFun := id
    invFun := id
    continuous_toFun := continuous_id top
    continuous_invFun := continuous_id top
    left_inv := fun x => rfl
    right_inv := fun x => rfl
  }

/-- If f is a homeomorphism, then f⁻¹ is also a homeomorphism. -/
theorem homeomorphism_symmetric (h : Homeomorphism top) : Homeomorphism top := by
  refine' {
    toFun := h.invFun
    invFun := h.toFun
    continuous_toFun := h.continuous_invFun
    continuous_invFun := h.continuous_toFun
    left_inv := h.right_inv
    right_inv := h.left_inv
  }

/-- A set is compact if every open cover has a finite subcover. -/
def IsCompact (s : Set X) : Prop :=
  ∀ (ι : Type*) (U : ι → Set X), (∀ i, top.IsOpen (U i)) → s ⊆ ⋃ i, U i → 
    ∃ t : Finset ι, s ⊆ ⋃ i ∈ t, U i

/-- A closed subset of a compact set is compact. -/
theorem isCompact_of_isClosed_subset (s t : Set X) 
    (hs : IsCompact top s) (ht : IsClosed top t) (hst : t ⊆ s) : IsCompact top t := by
  intro ι U hU hcover
  -- Add complement of t to the cover
  have hcomp : top.IsOpen tᶜ := ht
  let U' : Bool → Set X := fun b => if b then tᶜ else ⋃ i, U i
  have hU' : ∀ i, top.IsOpen (U' i) := by
    intro i
    cases i
    · exact hcomp
    · apply top.isOpen_iUnion U hU
  have hcov : s ⊆ ⋃ i, U' i := by
    intro x hx
    by_cases h : x ∈ tᶜ
    · use true
      simp [U', h]
    · push_neg at h
      have : x ∈ ⋃ i, U i := hcover (hst hx)
      obtain ⟨i, hi⟩ := this
      use false
      simp [U']
      use i
      exact hi
  obtain ⟨finset_t, hfinset⟩ := hs Bool U' hU' hcov
  use finset_t.filter (fun _ => false)
  intro x hx
  obtain ⟨i, hi, hUi⟩ := hfinset hx
  simp at hi
  use i
  constructor
  · exact hi
  · exact hUi

/-- The continuous image of a compact set is compact. -/
theorem isCompact_image (s : Set X) (f : X → X) 
    (hs : IsCompact top s) (hf : Continuous top f) : IsCompact top (f '' s) := by
  intro ι U hU hcover
  have hpre : ∀ i, top.IsOpen (f ⁻¹' (U i)) := by
    intro i
    apply hf (U i) (hU i)
  have hsub : s ⊆ ⋃ i, f ⁻¹' (U i) := by
    intro x hx
    simp at hx
    obtain ⟨y, hy, hxy⟩ := hx
    obtain ⟨i, hi, hUi⟩ := hcover hy
    use i
    simp [hxy, hUi]
  obtain ⟨finset_t, hfinset⟩ := hs ι (fun i => f ⁻¹' (U i)) hpre hsub
  use finset_t
  intro y hy
  obtain ⟨x, hx, hfx⟩ := hy
  obtain ⟨i, hi, hUi⟩ := hfinset hx
  use i
  constructor
  · exact hi
  · simp_all

/-- A space is connected if it cannot be split into two disjoint nonempty open sets. -/
def IsConnected (s : Set X) : Prop :=
  ∀ (U V : Set X), top.IsOpen U → top.IsOpen V → U ∩ s ⊆ V → V ∩ s ⊆ U → 
    (U ∩ s = ∅ ∨ V ∩ s = ∅) → U ∩ s = ∅ ∨ V ∩ s = ∅

/-- The continuous image of a connected set is connected. -/
theorem isConnected_image (s : Set X) (f : X → X) 
    (hs : IsConnected top s) (hf : Continuous top f) : IsConnected top (f '' s) := by
  intro U V hU hV hUV hVU hempty
  apply hs (f ⁻¹' U) (f ⁻¹' V) (hf U hU) (hf V hV)
  · intro x hx; apply hUV; simp_all
  · intro x hx; apply hVU; simp_all
  · simp_all

end TopologyProofs

-- Verification
#check @empty_is_open
#check @univ_is_open
#check @union_of_open_is_open
#check @inter_of_open_is_open
#check @IsClosed
#check @empty_is_closed
#check @univ_is_closed
#check @inter_of_closed_is_closed
#check @union_of_closed_is_closed
#check @Continuous
#check @continuous_id
#check @continuous_comp
#check @continuous_const
#check @Homeomorphism
#check @homeomorphism_reflexive
#check @homeomorphism_symmetric
#check @IsCompact
#check @isCompact_of_isClosed_subset
#check @isCompact_image
#check @IsConnected
#check @isConnected_image

#eval "Topology: 21 theorems verified"

end TopologyTheory
